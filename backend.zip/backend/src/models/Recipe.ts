import mongoose, { Schema, Document } from 'mongoose';

// Interface for TypeScript
export interface IRecipe extends Document {
  name: string;
  cuisine: string;
  dietaryType: string[];
  ingredients: {
    name: string;
    quantity: number;
    unit: string;
  }[];
  instructions: string[];
  prepTime: number;
  cookTime: number;
  servings: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  image: string;
  nutrition: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  tags: string[];
  createdAt?: Date;
  updatedAt?: Date;
}

// MongoDB Schema
const RecipeSchema: Schema = new Schema({
  name: {
    type: String,
    required: [true, 'Recipe name is required'],
    trim: true
  },
  cuisine: {
    type: String,
    required: [true, 'Cuisine type is required'],
    enum: ['Indian', 'American', 'Italian', 'Chinese', 'Japanese', 'African', 'Mexican', 'Thai', 'Other']
  },
  dietaryType: [{
    type: String,
    enum: ['Vegetarian', 'Non-Vegetarian', 'Vegan', 'Gluten-Free', 'Dairy-Free']
  }],
  ingredients: [{
    name: {
      type: String,
      required: true,
      trim: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 0
    },
    unit: {
      type: String,
      required: true,
      trim: true
    }
  }],
  instructions: [{
    type: String,
    required: true
  }],
  prepTime: {
    type: Number,
    required: true,
    min: 0
  },
  cookTime: {
    type: Number,
    required: true,
    min: 0
  },
  servings: {
    type: Number,
    default: 4,
    min: 1
  },
  difficulty: {
    type: String,
    enum: ['Easy', 'Medium', 'Hard'],
    default: 'Medium'
  },
  image: {
    type: String,
    default: 'https://via.placeholder.com/400x300?text=Recipe+Image'
  },
  nutrition: {
    calories: {
      type: Number,
      default: 0
    },
    protein: {
      type: Number,
      default: 0
    },
    carbs: {
      type: Number,
      default: 0
    },
    fat: {
      type: Number,
      default: 0
    }
  },
  tags: [{
    type: String,
    trim: true
  }]
}, {
  timestamps: true // Automatically adds createdAt and updatedAt
});

// Create text index for searching
RecipeSchema.index({ 
  name: 'text', 
  'ingredients.name': 'text',
  tags: 'text'
});

export default mongoose.model<IRecipe>('Recipe', RecipeSchema);