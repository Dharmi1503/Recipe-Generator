import { Request, Response } from 'express';
import Recipe, { IRecipe } from '../models/Recipe';

// Helper function to calculate match percentage
const calculateMatchScore = (userIngredients: string[], recipeIngredients: any[]): number => {
  const normalizedUserIngredients = userIngredients.map(ing => ing.toLowerCase().trim());
  const matches = recipeIngredients.filter(recipeIng => 
    normalizedUserIngredients.some(userIng => 
      recipeIng.name.toLowerCase().includes(userIng) || 
      userIng.includes(recipeIng.name.toLowerCase())
    )
  );
  return Math.round((matches.length / recipeIngredients.length) * 100);
};

// Helper function to adjust serving sizes
const adjustServings = (recipe: IRecipe, targetServings: number) => {
  const multiplier = targetServings / recipe.servings;
  return {
    ...recipe.toObject(),
    servings: targetServings,
    ingredients: recipe.ingredients.map(ing => ({
      ...ing,
      quantity: Math.round(ing.quantity * multiplier * 100) / 100
    }))
  };
};

// @desc    Get all recipes
// @route   GET /api/recipes
export const getAllRecipes = async (req: Request, res: Response) => {
  try {
    const recipes = await Recipe.find().sort({ createdAt: -1 });
    res.json({
      success: true,
      count: recipes.length,
      data: recipes
    });
  } catch (error: any) {
    res.status(500).json({ 
      success: false, 
      message: 'Server error', 
      error: error.message 
    });
  }
};

// @desc    Search recipes by ingredients
// @route   POST /api/recipes/search
export const searchRecipesByIngredients = async (req: Request, res: Response) => {
  try {
    const { 
      ingredients = [], 
      dietaryType, 
      cuisine, 
      servings 
    } = req.body;

    // Build query
    const query: any = {};
    
    if (dietaryType && dietaryType.length > 0) {
      query.dietaryType = { $in: dietaryType };
    }
    
    if (cuisine) {
      query.cuisine = cuisine;
    }

    // Get all matching recipes
    let recipes = await Recipe.find(query);

    // Calculate match scores
    const recipesWithScores = recipes.map(recipe => {
      const matchScore = calculateMatchScore(ingredients, recipe.ingredients);
      return {
        recipe: servings ? adjustServings(recipe, servings) : recipe.toObject(),
        matchScore
      };
    });

    // Sort by match score (highest first)
    recipesWithScores.sort((a, b) => b.matchScore - a.matchScore);

    // Filter recipes with at least 30% match
    const filteredRecipes = recipesWithScores.filter(item => item.matchScore >= 30);

    res.json({
      success: true,
      count: filteredRecipes.length,
      data: filteredRecipes
    });
  } catch (error: any) {
    res.status(500).json({ 
      success: false, 
      message: 'Error searching recipes', 
      error: error.message 
    });
  }
};

// @desc    Get single recipe by ID
// @route   GET /api/recipes/:id
export const getRecipeById = async (req: Request, res: Response) => {
  try {
    const { servings } = req.query;
    const recipe = await Recipe.findById(req.params.id);

    if (!recipe) {
      return res.status(404).json({ 
        success: false, 
        message: 'Recipe not found' 
      });
    }

    const adjustedRecipe = servings 
      ? adjustServings(recipe, parseInt(servings as string)) 
      : recipe;

    res.json({
      success: true,
      data: adjustedRecipe
    });
  } catch (error: any) {
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching recipe', 
      error: error.message 
    });
  }
};

// @desc    Create new recipe
// @route   POST /api/recipes
export const createRecipe = async (req: Request, res: Response) => {
  try {
    const recipe = await Recipe.create(req.body);
    res.status(201).json({
      success: true,
      data: recipe
    });
  } catch (error: any) {
    res.status(400).json({ 
      success: false, 
      message: 'Error creating recipe', 
      error: error.message 
    });
  }
};

// @desc    Update recipe
// @route   PUT /api/recipes/:id
export const updateRecipe = async (req: Request, res: Response) => {
  try {
    const recipe = await Recipe.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!recipe) {
      return res.status(404).json({ 
        success: false, 
        message: 'Recipe not found' 
      });
    }

    res.json({
      success: true,
      data: recipe
    });
  } catch (error: any) {
    res.status(400).json({ 
      success: false, 
      message: 'Error updating recipe', 
      error: error.message 
    });
  }
};

// @desc    Delete recipe
// @route   DELETE /api/recipes/:id
export const deleteRecipe = async (req: Request, res: Response) => {
  try {
    const recipe = await Recipe.findByIdAndDelete(req.params.id);

    if (!recipe) {
      return res.status(404).json({ 
        success: false, 
        message: 'Recipe not found' 
      });
    }

    res.json({
      success: true,
      message: 'Recipe deleted successfully'
    });
  } catch (error: any) {
    res.status(500).json({ 
      success: false, 
      message: 'Error deleting recipe', 
      error: error.message 
    });
  }
};