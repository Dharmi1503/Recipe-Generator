import express from 'express';
import {
  getAllRecipes,
  searchRecipesByIngredients,
  getRecipeById,
  createRecipe,
  updateRecipe,
  deleteRecipe
} from '../controllers/recipeController';

const router = express.Router();

// Recipe routes
router.get('/', getAllRecipes);
router.post('/search', searchRecipesByIngredients);
router.get('/:id', getRecipeById);
router.post('/', createRecipe);
router.put('/:id', updateRecipe);
router.delete('/:id', deleteRecipe);

export default router;