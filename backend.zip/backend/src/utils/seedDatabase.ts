import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Recipe from '../models/Recipe';
import { sampleRecipes } from './sampleData';

dotenv.config();

const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI as string);
    console.log('✅ MongoDB Connected');

    // Clear existing data
    await Recipe.deleteMany({});
    console.log('🗑️  Cleared existing recipes');

    // Insert sample data
    await Recipe.insertMany(sampleRecipes);
    console.log('✅ Sample recipes added successfully!');

    console.log(`📊 Total recipes: ${sampleRecipes.length}`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();