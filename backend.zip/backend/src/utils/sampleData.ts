export const sampleRecipes = [
  {
    name: "Butter Chicken",
    cuisine: "Indian",
    dietaryType: ["Non-Vegetarian"],
    ingredients: [
      { name: "Chicken", quantity: 500, unit: "g" },
      { name: "Butter", quantity: 50, unit: "g" },
      { name: "Tomatoes", quantity: 4, unit: "pieces" },
      { name: "Cream", quantity: 100, unit: "ml" },
      { name: "Onion", quantity: 2, unit: "pieces" },
      { name: "Garlic", quantity: 6, unit: "cloves" },
      { name: "Ginger", quantity: 1, unit: "inch" }
    ],
    instructions: [
      "Marinate chicken with yogurt and spices for 30 minutes",
      "Grill or pan-fry the chicken until cooked",
      "Prepare tomato-butter gravy with onions, garlic, and ginger",
      "Add cream and cooked chicken to the gravy",
      "Simmer for 10 minutes and serve hot"
    ],
    prepTime: 30,
    cookTime: 40,
    servings: 4,
    difficulty: "Medium",
    nutrition: {
      calories: 450,
      protein: 35,
      carbs: 15,
      fat: 28
    },
    tags: ["Curry", "Popular", "Rich"],
    image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400"
  },
  {
    name: "Vegetable Biryani",
    cuisine: "Indian",
    dietaryType: ["Vegetarian"],
    ingredients: [
      { name: "Rice", quantity: 2, unit: "cups" },
      { name: "Potatoes", quantity: 2, unit: "pieces" },
      { name: "Carrots", quantity: 2, unit: "pieces" },
      { name: "Peas", quantity: 1, unit: "cup" },
      { name: "Onion", quantity: 2, unit: "pieces" },
      { name: "Tomatoes", quantity: 2, unit: "pieces" },
      { name: "Yogurt", quantity: 100, unit: "ml" }
    ],
    instructions: [
      "Soak rice for 20 minutes",
      "Sauté vegetables with spices",
      "Layer rice and vegetables in a pot",
      "Cook on low heat for 20 minutes",
      "Serve with raita"
    ],
    prepTime: 25,
    cookTime: 35,
    servings: 4,
    difficulty: "Medium",
    nutrition: {
      calories: 380,
      protein: 12,
      carbs: 65,
      fat: 8
    },
    tags: ["Rice", "One-Pot", "Flavorful"],
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400"
  },
  {
    name: "Spaghetti Carbonara",
    cuisine: "Italian",
    dietaryType: ["Non-Vegetarian"],
    ingredients: [
      { name: "Spaghetti", quantity: 400, unit: "g" },
      { name: "Bacon", quantity: 200, unit: "g" },
      { name: "Eggs", quantity: 4, unit: "pieces" },
      { name: "Parmesan Cheese", quantity: 100, unit: "g" },
      { name: "Black Pepper", quantity: 1, unit: "tsp" },
      { name: "Garlic", quantity: 3, unit: "cloves" }
    ],
    instructions: [
      "Cook spaghetti according to package instructions",
      "Fry bacon until crispy",
      "Mix eggs with grated parmesan",
      "Toss hot pasta with bacon and egg mixture",
      "Season with black pepper and serve immediately"
    ],
    prepTime: 10,
    cookTime: 20,
    servings: 4,
    difficulty: "Easy",
    nutrition: {
      calories: 520,
      protein: 28,
      carbs: 55,
      fat: 22
    },
    tags: ["Pasta", "Quick", "Classic"],
    image: "https://images.unsplash.com/photo-1612874742237-6526221588e3?w=400"
  },
  {
    name: "Paneer Tikka",
    cuisine: "Indian",
    dietaryType: ["Vegetarian"],
    ingredients: [
      { name: "Paneer", quantity: 400, unit: "g" },
      { name: "Yogurt", quantity: 150, unit: "ml" },
      { name: "Bell Peppers", quantity: 2, unit: "pieces" },
      { name: "Onion", quantity: 1, unit: "piece" },
      { name: "Lemon", quantity: 1, unit: "piece" }
    ],
    instructions: [
      "Cut paneer and vegetables into cubes",
      "Marinate with yogurt and spices for 1 hour",
      "Thread onto skewers",
      "Grill or bake until charred",
      "Serve with mint chutney"
    ],
    prepTime: 70,
    cookTime: 20,
    servings: 4,
    difficulty: "Easy",
    nutrition: {
      calories: 320,
      protein: 22,
      carbs: 12,
      fat: 20
    },
    tags: ["Appetizer", "Grilled", "Protein-Rich"],
    image: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400"
  },
  {
    name: "Chicken Fried Rice",
    cuisine: "Chinese",
    dietaryType: ["Non-Vegetarian"],
    ingredients: [
      { name: "Rice", quantity: 3, unit: "cups" },
      { name: "Chicken", quantity: 300, unit: "g" },
      { name: "Eggs", quantity: 2, unit: "pieces" },
      { name: "Carrots", quantity: 1, unit: "piece" },
      { name: "Peas", quantity: 0.5, unit: "cup" },
      { name: "Soy Sauce", quantity: 3, unit: "tbsp" },
      { name: "Garlic", quantity: 4, unit: "cloves" }
    ],
    instructions: [
      "Use day-old cooked rice",
      "Stir-fry chicken until cooked",
      "Scramble eggs separately",
      "Stir-fry vegetables",
      "Combine everything and season with soy sauce"
    ],
    prepTime: 15,
    cookTime: 15,
    servings: 4,
    difficulty: "Easy",
    nutrition: {
      calories: 420,
      protein: 25,
      carbs: 58,
      fat: 10
    },
    tags: ["Rice", "Quick", "Stir-Fry"],
    image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400"
  }
];